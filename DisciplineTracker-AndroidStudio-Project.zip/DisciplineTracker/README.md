# My 30-Day Discipline Tracker (Android, Kotlin + Jetpack Compose)

Native Android app. 30-day habit grid, tap-to-tick boxes, editable tasks, daily score,
milestones (Day 7/14/21/30), all saved locally on the phone. No login, no internet.

## Build the APK

### Option A – Android Studio (easiest on a PC/Mac)
1. Install Android Studio (https://developer.android.com/studio).
2. File > Open > choose this `DisciplineTracker` folder. Wait for the Gradle sync.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Click "locate" in the popup. The file is `app/build/outputs/apk/debug/app-debug.apk`.

### Option B – command line
Needs JDK 17+ and the Android SDK (platform 35). Set `ANDROID_HOME` to the SDK folder, then:

    ./gradlew assembleDebug        # Windows: gradlew.bat assembleDebug

APK: `app/build/outputs/apk/debug/app-debug.apk`

### Option C – no install, in the cloud (GitHub Actions)
1. Create a free GitHub account and a new repository.
2. Upload every file in this folder (keep the `.github` folder).
3. Open the repository's **Actions** tab > "Build APK" > wait for the green tick.
4. Open that run and download the artifact "My-30-Day-Discipline-Tracker-APK" (a zip containing `app-debug.apk`).

## Install on your phone
1. Copy `app-debug.apk` to your phone (USB, Google Drive, WhatsApp-to-self, email).
2. Open it from the Files/Downloads app.
3. If asked, allow "Install unknown apps" for that app (Chrome/Files), then tap Install.
4. Open **My 30-Day Discipline Tracker** from your app drawer.

## Notes
- Data is stored in the app's private storage. Uninstalling the app erases it.
- Requires Android 8.0 (API 26) or newer.
