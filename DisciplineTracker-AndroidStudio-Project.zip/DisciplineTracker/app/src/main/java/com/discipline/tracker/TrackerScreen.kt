package com.discipline.tracker

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.lightColorScheme
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalDate
import java.time.format.DateTimeFormatter

private val Navy = Color(0xFF1E3A5F)
private val Green = Color(0xFF2E9E5B)
private val GreenLight = Color(0xFFDDF3E4)
private val TodayTint = Color(0xFFFFF6D6)
private val PageBg = Color(0xFFF4F6FA)
private val GridBorder = Color(0xFFB8C2D0)
private val Muted = Color(0xFF5B6675)
private val Danger = Color(0xFFC62828)

private val MILESTONE_DAYS = listOf(7, 14, 21, 30)
private const val DAYS = 30

@Composable
fun TrackerTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Navy,
            onPrimary = Color.White,
            secondary = Green,
            background = PageBg,
            surface = Color.White,
        ),
        content = content,
    )
}

@Composable
fun TrackerScreen(vm: TrackerViewModel) {
    val s = vm.state
    var editing by remember { mutableStateOf<Task?>(null) }
    var adding by remember { mutableStateOf(false) }

    val today: Int? = s.startDay?.let {
        val d = (LocalDate.now().toEpochDay() - it + 1).toInt()
        if (d in 1..DAYS) d else null
    }

    Scaffold(
        containerColor = PageBg,
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { adding = true },
                containerColor = Navy,
                contentColor = Color.White,
            ) {
                Text("+ Add Task", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }
        },
    ) { pad ->
        Column(
            Modifier
                .padding(pad)
                .imePadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Header()
            ProfileCard(s, vm)
            SectionCard {
                Text("MY DAILY HABITS", fontWeight = FontWeight.Bold, color = Navy, fontSize = 15.sp)
                Text(
                    "Tap a box to tick it, tap again to untick. Tap a task name to edit or remove it. Swipe the grid sideways for days 1–30.",
                    fontSize = 12.sp,
                    color = Muted,
                )
                Spacer(Modifier.height(8.dp))
                if (s.tasks.isEmpty()) {
                    Text("No tasks yet. Tap “+ Add Task” to create one.", color = Muted)
                } else {
                    TrackerGrid(s, today, onToggle = vm::toggle, onEdit = { editing = it })
                }
            }
            SummaryCard(s, today)
            Text("MILESTONES", fontWeight = FontWeight.Bold, color = Navy, fontSize = 15.sp)
            MILESTONE_DAYS.forEach { day ->
                val m = s.milestones[day] ?: Milestone()
                MilestoneCard(
                    day = day,
                    reached = today != null && today >= day,
                    milestone = m,
                    onReward = { vm.setReward(day, it) },
                    onLesson = { vm.setLesson(day, it) },
                )
            }
            Spacer(Modifier.height(80.dp)) // keeps content clear of the + Add Task button
        }
    }

    if (adding) {
        TaskDialog(
            task = null,
            onSave = { time, name -> vm.addTask(time, name); adding = false },
            onDelete = null,
            onDismiss = { adding = false },
        )
    }
    editing?.let { t ->
        TaskDialog(
            task = t,
            onSave = { time, name -> vm.editTask(t.id, time, name); editing = null },
            onDelete = { vm.removeTask(t.id); editing = null },
            onDismiss = { editing = null },
        )
    }
}

@Composable
private fun Header() {
    Column(Modifier.padding(top = 4.dp)) {
        Text(
            "30-DAY DISCIPLINE SCHEDULE",
            fontSize = 22.sp,
            fontWeight = FontWeight.ExtraBold,
            color = Navy,
        )
        Text(
            "Beat yesterday: more focus, more consistency, better form.",
            fontSize = 13.sp,
            color = Muted,
        )
    }
}

@Composable
private fun SectionCard(content: @Composable () -> Unit) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            content()
        }
    }
}

@Composable
private fun ProfileCard(s: AppState, vm: TrackerViewModel) {
    SectionCard {
        OutlinedTextField(
            value = s.name,
            onValueChange = vm::setName,
            label = { Text("Name") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
        )
        StartDateField(s.startDay, onPick = vm::setStartDay)
        OutlinedTextField(
            value = s.goal,
            onValueChange = vm::setGoal,
            label = { Text("Main goal") },
            minLines = 1,
            maxLines = 4,
            modifier = Modifier.fillMaxWidth(),
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun StartDateField(startDay: Long?, onPick: (Long) -> Unit) {
    var show by remember { mutableStateOf(false) }
    val label = startDay?.let {
        LocalDate.ofEpochDay(it).format(DateTimeFormatter.ofPattern("dd MMM yyyy"))
    } ?: "Tap to choose"
    OutlinedButton(
        onClick = { show = true },
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = 54.dp),
    ) {
        Text("Start date: $label", fontSize = 15.sp)
    }
    if (show) {
        val pickerState = rememberDatePickerState(
            initialSelectedDateMillis = (startDay ?: LocalDate.now().toEpochDay()) * 86_400_000L,
        )
        DatePickerDialog(
            onDismissRequest = { show = false },
            confirmButton = {
                TextButton(onClick = {
                    pickerState.selectedDateMillis?.let { onPick(Math.floorDiv(it, 86_400_000L)) }
                    show = false
                }) { Text("OK") }
            },
            dismissButton = { TextButton(onClick = { show = false }) { Text("Cancel") } },
        ) {
            DatePicker(state = pickerState)
        }
    }
}

@Composable
private fun TrackerGrid(
    s: AppState,
    today: Int?,
    onToggle: (Long, Int) -> Unit,
    onEdit: (Task) -> Unit,
) {
    val labelW = 128.dp
    val cell = 44.dp
    val head = 40.dp
    val total = s.tasks.size

    Row(Modifier.fillMaxWidth()) {
        // Fixed left column: habit names
        Column(Modifier.width(labelW)) {
            Box(
                Modifier
                    .size(labelW, head)
                    .background(Navy)
                    .border(0.5.dp, GridBorder),
                contentAlignment = Alignment.CenterStart,
            ) {
                Text(
                    "HABIT",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    modifier = Modifier.padding(start = 8.dp),
                )
            }
            s.tasks.forEach { t ->
                Column(
                    Modifier
                        .size(labelW, cell)
                        .border(0.5.dp, GridBorder)
                        .clickable { onEdit(t) }
                        .padding(horizontal = 6.dp),
                    verticalArrangement = Arrangement.Center,
                ) {
                    Text(
                        t.time,
                        fontSize = 10.sp,
                        color = Muted,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Text(
                        t.name,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }
            Box(
                Modifier
                    .size(labelW, cell)
                    .background(Color(0xFFEAF0F8))
                    .border(0.5.dp, GridBorder),
                contentAlignment = Alignment.CenterStart,
            ) {
                Text(
                    "DAY SCORE",
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    color = Navy,
                    modifier = Modifier.padding(start = 8.dp),
                )
            }
        }

        // Scrollable right part: days 1..30
        Column(Modifier.horizontalScroll(rememberScrollState())) {
            Row {
                for (d in 1..DAYS) {
                    Box(
                        Modifier
                            .size(cell, head)
                            .background(if (d == today) Green else Navy)
                            .border(0.5.dp, GridBorder),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(
                            "$d",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                        )
                    }
                }
            }
            s.tasks.forEach { t ->
                Row {
                    for (d in 1..DAYS) {
                        val checked = checkKey(t.id, d) in s.checks
                        Box(
                            Modifier
                                .size(cell)
                                .background(
                                    when {
                                        checked -> GreenLight
                                        d == today -> TodayTint
                                        else -> Color.White
                                    }
                                )
                                .border(0.5.dp, GridBorder)
                                .clickable(role = Role.Checkbox) { onToggle(t.id, d) },
                            contentAlignment = Alignment.Center,
                        ) {
                            if (checked) {
                                Text(
                                    "✓",
                                    color = Green,
                                    fontSize = 24.sp,
                                    fontWeight = FontWeight.Bold,
                                )
                            }
                        }
                    }
                }
            }
            Row {
                for (d in 1..DAYS) {
                    val done = s.tasks.count { checkKey(it.id, d) in s.checks }
                    val perfect = total > 0 && done == total
                    Box(
                        Modifier
                            .size(cell)
                            .background(if (perfect) GreenLight else Color(0xFFEAF0F8))
                            .border(0.5.dp, GridBorder),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(
                            "$done/$total",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (perfect) Green else Navy,
                            textAlign = TextAlign.Center,
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SummaryCard(s: AppState, today: Int?) {
    val total = s.tasks.size
    val done = s.checks.size
    val possible = total * DAYS
    val pct = if (possible == 0) 0 else done * 100 / possible

    fun isPerfect(d: Int) = total > 0 && s.tasks.all { checkKey(it.id, d) in s.checks }
    val perfectDays = (1..DAYS).count { isPerfect(it) }
    var best = 0
    var run = 0
    for (d in 1..DAYS) {
        if (isPerfect(d)) {
            run++
            if (run > best) best = run
        } else run = 0
    }
    val todayDone = today?.let { d -> s.tasks.count { checkKey(it.id, d) in s.checks } }

    SectionCard {
        Text("PROGRESS SUMMARY", fontWeight = FontWeight.Bold, color = Navy, fontSize = 15.sp)
        LinearProgressIndicator(
            progress = { pct / 100f },
            color = Green,
            modifier = Modifier
                .fillMaxWidth()
                .height(8.dp),
        )
        Text("$done of $possible boxes ticked ($pct%)", fontSize = 14.sp)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Stat("Perfect days", "$perfectDays")
            Stat("Best streak", "$best")
            Stat("Today", if (todayDone != null) "$todayDone/$total" else "–")
        }
        if (today == null) {
            Text(
                "Choose a start date above to highlight today's column.",
                fontSize = 12.sp,
                color = Muted,
            )
        }
    }
}

@Composable
private fun Stat(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, color = Navy)
        Text(label, fontSize = 12.sp, color = Muted)
    }
}

@Composable
private fun MilestoneCard(
    day: Int,
    reached: Boolean,
    milestone: Milestone,
    onReward: (String) -> Unit,
    onLesson: (String) -> Unit,
) {
    SectionCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                "DAY $day MILESTONE",
                fontWeight = FontWeight.Bold,
                color = Navy,
                fontSize = 15.sp,
                modifier = Modifier.weight(1f),
            )
            if (reached) Text("Reached ✓", color = Green, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        }
        OutlinedTextField(
            value = milestone.reward,
            onValueChange = onReward,
            label = { Text("Reward") },
            modifier = Modifier.fillMaxWidth(),
        )
        OutlinedTextField(
            value = milestone.lesson,
            onValueChange = onLesson,
            label = { Text("Lesson") },
            minLines = 2,
            modifier = Modifier.fillMaxWidth(),
        )
    }
}

@Composable
private fun TaskDialog(
    task: Task?,
    onSave: (time: String, name: String) -> Unit,
    onDelete: (() -> Unit)?,
    onDismiss: () -> Unit,
) {
    var time by remember(task?.id) { mutableStateOf(task?.time ?: "") }
    var name by remember(task?.id) { mutableStateOf(task?.name ?: "") }
    var confirmDelete by remember { mutableStateOf(false) }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Remove task?") },
            text = { Text("“${task?.name}” and all of its ticks will be deleted.") },
            confirmButton = {
                TextButton(onClick = { onDelete?.invoke() }) { Text("Remove", color = Danger) }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Keep") } },
        )
    } else {
        AlertDialog(
            onDismissRequest = onDismiss,
            title = { Text(if (task == null) "Add task" else "Edit task") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = time,
                        onValueChange = { time = it },
                        label = { Text("Time (e.g. 4:30–4:50 AM)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                    )
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("Task name") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                    )
                    if (onDelete != null) {
                        TextButton(onClick = { confirmDelete = true }) {
                            Text("Remove this task", color = Danger)
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(
                    enabled = name.isNotBlank(),
                    onClick = { onSave(time.trim(), name.trim()) },
                ) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
        )
    }
}
