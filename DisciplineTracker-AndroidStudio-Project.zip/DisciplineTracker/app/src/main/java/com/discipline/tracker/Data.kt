package com.discipline.tracker

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** One row of the tracker grid. */
data class Task(val id: Long, val time: String, val name: String)

data class Milestone(val reward: String = "", val lesson: String = "")

data class AppState(
    val name: String = "",
    /** Start date stored as epoch day (days since 1970-01-01), or null if not chosen. */
    val startDay: Long? = null,
    val goal: String = "",
    val tasks: List<Task> = defaultTasks(),
    /** Set of "taskId:day" keys; a key is present when that box is ticked. */
    val checks: Set<String> = emptySet(),
    /** Keyed by milestone day: 7, 14, 21, 30. */
    val milestones: Map<Int, Milestone> = emptyMap(),
)

fun checkKey(taskId: Long, day: Int): String = "$taskId:$day"

fun defaultTasks(): List<Task> = listOf(
    Task(1, "4:00 AM", "Wake Up"),
    Task(2, "4:00–4:30 AM", "Weight Loss"),
    Task(3, "4:30–4:50 AM", "Workout"),
    Task(4, "4:52–5:00 AM", "Meditation"),
    Task(5, "5:00–5:50 AM", "Trading"),
    Task(6, "5:50–6:20 AM", "Flower"),
    Task(7, "6:20–8:00 AM", "Cow"),
    Task(8, "8:00–9:00 AM", "Rest / Eating"),
    Task(9, "9:00–10:00 AM", "Home Cleaning"),
    Task(10, "10:00–11:00 AM", "Cloth Washing"),
)

/** Saves everything locally on the phone (SharedPreferences, JSON). No network needed. */
class Store(context: Context) {
    private val prefs = context.applicationContext
        .getSharedPreferences("discipline_tracker", Context.MODE_PRIVATE)

    fun load(): AppState {
        val raw = prefs.getString(KEY, null) ?: return AppState()
        return try {
            parse(JSONObject(raw))
        } catch (e: Exception) {
            AppState()
        }
    }

    fun save(state: AppState) {
        prefs.edit().putString(KEY, toJson(state).toString()).apply()
    }

    private fun parse(o: JSONObject): AppState {
        val taskArr = o.getJSONArray("tasks")
        val tasks = (0 until taskArr.length()).map {
            val t = taskArr.getJSONObject(it)
            Task(t.getLong("id"), t.getString("time"), t.getString("name"))
        }
        val checkArr = o.getJSONArray("checks")
        val checks = (0 until checkArr.length()).map { checkArr.getString(it) }.toSet()
        val msObj = o.getJSONObject("milestones")
        val milestones = msObj.keys().asSequence().associate { k ->
            val m = msObj.getJSONObject(k)
            k.toInt() to Milestone(m.optString("reward"), m.optString("lesson"))
        }
        return AppState(
            name = o.optString("name"),
            startDay = if (o.has("startDay")) o.getLong("startDay") else null,
            goal = o.optString("goal"),
            tasks = tasks,
            checks = checks,
            milestones = milestones,
        )
    }

    private fun toJson(s: AppState): JSONObject {
        val o = JSONObject()
        o.put("name", s.name)
        s.startDay?.let { o.put("startDay", it) }
        o.put("goal", s.goal)
        val taskArr = JSONArray()
        s.tasks.forEach {
            taskArr.put(JSONObject().put("id", it.id).put("time", it.time).put("name", it.name))
        }
        o.put("tasks", taskArr)
        val checkArr = JSONArray()
        s.checks.forEach { checkArr.put(it) }
        o.put("checks", checkArr)
        val msObj = JSONObject()
        s.milestones.forEach { (day, m) ->
            msObj.put(day.toString(), JSONObject().put("reward", m.reward).put("lesson", m.lesson))
        }
        o.put("milestones", msObj)
        return o
    }

    private companion object {
        const val KEY = "state"
    }
}
