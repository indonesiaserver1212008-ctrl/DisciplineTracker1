package com.discipline.tracker

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel

/** Holds the app state; every change is saved to local storage immediately. */
class TrackerViewModel(app: Application) : AndroidViewModel(app) {
    private val store = Store(app)

    var state by mutableStateOf(store.load())
        private set

    private fun update(change: (AppState) -> AppState) {
        state = change(state)
        store.save(state)
    }

    fun toggle(taskId: Long, day: Int) = update { s ->
        val key = checkKey(taskId, day)
        s.copy(checks = if (key in s.checks) s.checks - key else s.checks + key)
    }

    fun addTask(time: String, name: String) = update { s ->
        val id = (s.tasks.maxOfOrNull { it.id } ?: 0L) + 1L
        s.copy(tasks = s.tasks + Task(id, time, name))
    }

    fun editTask(id: Long, time: String, name: String) = update { s ->
        s.copy(tasks = s.tasks.map { if (it.id == id) it.copy(time = time, name = name) else it })
    }

    fun removeTask(id: Long) = update { s ->
        val prefix = "$id:"
        s.copy(
            tasks = s.tasks.filterNot { it.id == id },
            checks = s.checks.filterNot { it.startsWith(prefix) }.toSet(),
        )
    }

    fun setName(v: String) = update { it.copy(name = v) }
    fun setGoal(v: String) = update { it.copy(goal = v) }
    fun setStartDay(v: Long) = update { it.copy(startDay = v) }

    fun setReward(day: Int, v: String) = update { s ->
        val m = s.milestones[day] ?: Milestone()
        s.copy(milestones = s.milestones + (day to m.copy(reward = v)))
    }

    fun setLesson(day: Int, v: String) = update { s ->
        val m = s.milestones[day] ?: Milestone()
        s.copy(milestones = s.milestones + (day to m.copy(lesson = v)))
    }
}
